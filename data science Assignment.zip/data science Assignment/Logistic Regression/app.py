import streamlit as st
import pickle
import numpy as np
import pandas as pd

# Title
st.title("🚢 Titanic Survival Prediction App")

# Load model and scaler
model = pickle.load(open('logistic_model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

# Input fields
st.header("Enter Passenger Details")

passenger_id = st.number_input("Passenger ID", min_value=1, value=123)
pclass = st.selectbox("Ticket Class (Pclass)", [1, 2, 3])
sex = st.selectbox("Sex", ["male", "female"])
age = st.number_input("Age", min_value=0.0, value=28.0)
sibsp = st.number_input("No. of Siblings/Spouses Aboard (SibSp)", min_value=0, value=0)
parch = st.number_input("No. of Parents/Children Aboard (Parch)", min_value=0, value=0)
fare = st.number_input("Ticket Fare", min_value=0.0, value=30.0)
embarked = st.selectbox("Port of Embarkation", ['C', 'Q', 'S'])

# Convert categorical values
sex_val = 1 if sex == 'male' else 0
embarked_c = 1 if embarked == 'C' else 0
embarked_q = 1 if embarked == 'Q' else 0
embarked_s = 1 if embarked == 'S' else 0

# Prepare input
input_data = np.array([[
    passenger_id,
    pclass,
    sex_val,
    age,
    sibsp,
    parch,
    fare,
    embarked_c,
    embarked_q,
    embarked_s
]])

# Predict button
if st.button("Predict Survival"):
    input_scaled = scaler.transform(input_data)
    prediction = model.predict(input_scaled)
    probability = model.predict_proba(input_scaled)[0][1]

    if prediction[0] == 1:
        st.success(f"✅ Survived (Probability: {probability:.2f})")
    else:
        st.error(f"❌ Did not Survive (Probability: {probability:.2f})")


