import pandas as pd

# Load the Excel file (replace the file name with your actual file name)
df = pd.read_csv("sales_data_with_discounts.csv")

# Display first few rows
print("First 5 rows of the dataset:")
print(df.head())

# Check data types
print("\nData Types:")
print(df.dtypes)


# Mean, median, mode and standard deviation
